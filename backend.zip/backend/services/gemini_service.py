# services/gemini_service.py
import httpx
import json
from typing import List, Dict, Any
from config import GEMINI_API_KEY, GEMINI_BASE_URL

# Models
from models.verification_models import Claim, SourceInfo, VerificationResultSummary

# For safety keep small retries
from utils.retries import retry_async


async def _call_gemini(prompt: str, model: str = "gemini-2.5-flash") -> str:
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is not configured")

    url = f"{GEMINI_BASE_URL}/models/{model}:generateContent?key={GEMINI_API_KEY}"
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.1,
            "topK": 40,
            "topP": 0.95,
            "maxOutputTokens": 1024
        }
    }

    async with httpx.AsyncClient(timeout=30.0) as client:
        r = await client.post(url, json=body)
        r.raise_for_status()
        data = r.json()
        # data.candidates[0].content.parts[0].text is where your TS file read from
        try:
            return data["candidates"][0]["content"]["parts"][0]["text"]
        except Exception:
            # fallback: try stringifying whole answer
            return json.dumps(data)


async def extract_claims(content: str) -> List[Claim]:
    """
    Calls Gemini with a prompt to extract claims; returns list of Claim objects
    NOTE: This function expects Gemini to return a JSON array; we parse accordingly.
    """
    prompt = f"""
Analyze the following text and extract verifiable claims. Return only a JSON array.
Text: \"{content[:3000]}\"

Return up to 8 claims in this structure:
[
  {{"id": "claim_1", "text": "...", "type": "factual|opinion|prediction|statistic", "confidence": 85, "context": "..." }}
]
"""
    # Try several models (like your TS code did)
    models = ["gemini-2.5-flash", "gemini-2.5-flash-latest", "gemini-2.5-pro"]
    last_error = None
    for m in models:
        try:
            resp_text = await retry_async(lambda: _call_gemini(prompt, model=m), retries=2, delay=1.0)
            # Clean and parse JSON array inside resp_text
            text = resp_text.strip()
            text = text.replace("```json", "").replace("```", "")
            import re
            match = re.search(r"(\[[\s\S]*\])", text)
            json_str = match.group(1) if match else text
            parsed = json.loads(json_str)
            claims = []
            for i, item in enumerate(parsed):
                try:
                    claim = Claim(
                        id=item.get("id") or f"claim_{i+1}",
                        text=(item.get("text") or "").strip(),
                        type=item.get("type") if item.get("type") in ["factual","opinion","prediction","statistic"] else "factual",
                        confidence=int(item.get("confidence") or 70),
                        context=item.get("context")
                    )
                    claims.append(claim)
                except Exception:
                    continue
            if claims:
                return claims
        except Exception as e:
            last_error = e
            continue

    # fallback simple heuristic: split sentences
    sents = [s.strip() for s in content.split('.') if len(s.strip()) > 30][:3]
    fallback = []
    for i, s in enumerate(sents):
        fallback.append(Claim(id=f"fallback_{i+1}", text=s, type="factual", confidence=60, context="fallback"))
    return fallback


async def verify_against_sources(claims: List[Claim], articles: List[Dict[str, Any]], original_content: str) -> VerificationResultSummary:
    """
    High-level: send a prompt to Gemini asking to analyze claims against summary of articles,
    then parse the returned JSON-like object. If Gemini request fails, create fallback summary.
    """
    articles_text = ""
    for a in articles[:8]:
        src = a.get("source", {}).get("name", "Unknown")
        title = a.get("title", "")
        desc = (a.get("description") or "")[:500]
        articles_text += f"Source: {src}\nTitle: {title}\nDescription: {desc}\nURL: {a.get('url')}\n\n"

    claims_text = "\n".join([f"{c.id}: {c.text} (type: {c.type}, conf: {c.confidence})" for c in claims])

    prompt = f"""
You are a fact checking expert. Evaluate the following CLAIMS and ORIGINAL CONTENT against VERIFIED NEWS SOURCES. Return ONLY a JSON object with this exact structure:

{{
  "truthScore": 75,
  "isLikelyMisinformation": false,
  "reasons": ["..."],
  "supportingArticles": 3,
  "contradictingArticles": 0,
  "verificationSummary": "...",
  "sources": [
    {{"name":"BBC","url":"https://...","reliability":95,"stance":"supports"}}
  ]
}}

CLAIMS:
{claims_text}

ORIGINAL:
{original_content[:2000]}

SOURCES:
{articles_text}
"""
    try:
        resp_text = await retry_async(lambda: _call_gemini(prompt, model="gemini-2.5-flash"), retries=2, delay=1.0)
        text = resp_text.strip().replace("```json", "").replace("```", "")
        import re, json
        match = re.search(r"(\{[\s\S]*\})", text)
        if match:
            json_str = match.group(1)
            parsed = json.loads(json_str)
            # Map to VerificationResultSummary
            sources_parsed = []
            for s in parsed.get("sources", [])[:8]:
                try:
                    sources_parsed.append(SourceInfo(
                        name=s.get("name", "Unknown"),
                        url=s.get("url"),
                        reliability=int(s.get("reliability", 75)),
                        stance=s.get("stance", "neutral")
                    ))
                except Exception:
                    continue
            vs = VerificationResultSummary(
                truthScore = int(parsed.get("truthScore", 75)),
                isLikelyMisinformation = bool(parsed.get("isLikelyMisinformation", False)),
                reasons = parsed.get("reasons", [])[:5] if isinstance(parsed.get("reasons", []), list) else ["Analysis done"],
                supportingArticles = int(parsed.get("supportingArticles", 0)),
                contradictingArticles = int(parsed.get("contradictingArticles", 0)),
                verificationSummary = parsed.get("verificationSummary", ""),
                sources = sources_parsed
            )
            return vs
    except Exception:
        pass

    # fallback: compute a simple estimate
    avg_reliability = 75
    supporting = len(articles)//2
    contradicting = len(articles) - supporting
    vs = VerificationResultSummary(
        truthScore = min(90, max(40, int(avg_reliability))),
        isLikelyMisinformation = (avg_reliability < 60),
        reasons = ["Fallback verification: limited sources or Gemini unavailable."],
        supportingArticles = supporting,
        contradictingArticles = contradicting,
        verificationSummary = "Fallback: basic check against available sources.",
        sources = [SourceInfo(name=a.get("source",{}).get("name","Unknown"), url=a.get("url"), reliability=75, stance="supports") for a in articles[:3]]
    )
    return vs
