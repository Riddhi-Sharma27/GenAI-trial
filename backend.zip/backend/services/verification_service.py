# services/verification_service.py
import time
from typing import List, Dict, Any
from models.verification_models import Claim, CompleteVerificationResult, ProcessedInput, VerificationResultSummary
from services.webscraper_service import webscraper_service
from services.news_service import news_service
from services.gemini_service import extract_claims, verify_against_sources
from utils.retries import retry_async
from datetime import datetime

async def process_input(input_type: str, content: str) -> ProcessedInput:
    if input_type == "text":
        return ProcessedInput(originalContent=content, extractedText=content, title="User Submitted Text")
    elif input_type == "link":
        try:
            scraped = await webscraper_service.scrape_url(content)
            return ProcessedInput(
                originalContent = content,
                extractedText = scraped.get("content", f"Content from {content}"),
                title = scraped.get("title"),
                url = scraped.get("url"),
                source = scraped.get("siteName")
            )
        except Exception as e:
            # fallback: treat URL string as text
            return ProcessedInput(originalContent=content, extractedText=f"Content from URL: {content}", title="Link Content", url=content)
    elif input_type == "video":
        # Right now we don't do heavy video processing: treat description as text
        return ProcessedInput(originalContent=content, extractedText=f"Video content: {content}", title="Video Content")
    else:
        raise ValueError("Unsupported input type")

async def verify_content(input_type: str, content: str) -> CompleteVerificationResult:
    start = time.time()
    processed = await process_input(input_type, content)

    # 1) extract claims (use gemini)
    claims: List[Claim] = await extract_claims(processed.extractedText)

    # 2) search news using keywords
    # simple query builder: first 6 words or keywords
    words = [w for w in processed.extractedText.split() if len(w) > 3][:8]
    query = " ".join(words) if words else "news"
    try:
        articles = await news_service.search_news(query, page_size=15)
    except Exception:
        articles = []

    # 3) verify against sources (Gemini)
    verification_summary: VerificationResultSummary = await verify_against_sources(claims, articles, processed.extractedText)

    processing_time = int((time.time() - start) * 1000)

    result = CompleteVerificationResult(
        claims = claims,
        verification = verification_summary,
        input = processed,
        relatedArticles = articles[:10],
        processingTime = processing_time,
        timestamp = datetime.utcnow().isoformat() + "Z"
    )
    return result
