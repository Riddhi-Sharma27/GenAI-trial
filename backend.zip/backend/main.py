# main.py
from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from models.verification_models import CompleteVerificationResult
from services.verification_service import verify_content
from pydantic import BaseModel
import config

app = FastAPI(title="TruthLens Backend", version="0.1.0")

# CORS - allow frontend origin
origins = [
    config.FRONTEND_ORIGIN,
    "http://localhost:3000",
    "http://127.0.0.1:3000",
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Backend is working"}

class VerifyRequest(BaseModel):
    type: str  # "text" | "link" | "video"
    content: str

@app.post("/verify", response_model=CompleteVerificationResult)
async def verify(req: VerifyRequest):
    try:
        if req.type not in ("text", "link", "video"):
            raise HTTPException(status_code=400, detail="Invalid type")
        result = await verify_content(req.type, req.content)
        return result
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Optional: endpoint to upload a video file (for future work)
@app.post("/upload-video")
async def upload_video(file: UploadFile = File(...)):
    # Save temporarily and return saved path or id
    try:
        contents = await file.read()
        # For demo: write to a tmp file
        with open(f"/tmp/{file.filename}", "wb") as f:
            f.write(contents)
        return {"status": "ok", "filename": file.filename}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
